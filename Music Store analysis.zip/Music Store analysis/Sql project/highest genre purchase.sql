with pg as (
  select count(invoice_line.quantity) as purchase,customer.country,genre.name,genre.genre_id,
  row_number() over(partition by customer.country order by count(invoice_line.quantity)desc) as rowno
	from invoice_line
	join invoice on invoice_line.invoice_id = invoice.invoice_id
	join customer on invoice.customer_id = customer.customer_id
	join track on invoice_line.track_id = track.track_id
	join genre on genre.genre_id = track.genre_id
	group by 2,3,4
	order by 1 desc
)
select * from pg where rowno <=1

--with recursive

with recursive sales_per_country as (
    select count(*) as purchase_per_genre, customer.country, genre.name, genre.genre_id
    from invoice_line
    join invoice on invoice_line.invoice_id = invoice.invoice_id
    join customer on invoice.customer_id = customer.customer_id
    join track on invoice_line.track_id = track.track_id
    join genre on genre.genre_id = track.genre_id
    group by customer.country, genre.name, genre.genre_id
),
max_genre_per_country as (
    select max(purchase_per_genre) as max_genre_number, country
    from sales_per_country
    group by country
)
select sales_per_country.*
from sales_per_country
join max_genre_per_country on sales_per_country.country = max_genre_per_country.country
where sales_per_country.purchase_per_genre = max_genre_per_country.max_genre_number
order by purchase_per_genre desc
