with most_purchase as (
    select customer.customer_id,customer.first_name,customer.last_name,
	invoice.billing_country,sum(invoice.total)as spent,
    ROW_NUMBER() over (partition by invoice.billing_country order by sum(invoice.total) desc) as rowno
    from invoice
	join customer on invoice.customer_id = customer.customer_id
    group by 1,2,3,4
    order by spent desc
	)
select *from most_purchase where rowno =1
order by most_purchase.billing_country asc
