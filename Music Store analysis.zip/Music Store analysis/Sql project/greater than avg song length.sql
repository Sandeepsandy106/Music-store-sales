select name,milliseconds from track
where milliseconds >(
   select avg(milliseconds) as avrg_len
	from track
)
order by milliseconds desc