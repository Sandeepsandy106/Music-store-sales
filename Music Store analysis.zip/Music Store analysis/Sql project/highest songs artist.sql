SELECT artist.name, artist.artist_id, count(artist.artist_id) as Songs
FROM track
JOIN album ON album.album_id = track.album_id
join artist on artist.artist_id = album.artist_id
join genre on genre.genre_id =track.genre_id
where genre.name like 'Rock'
group by artist.artist_id
order by songs desc
limit 10	

